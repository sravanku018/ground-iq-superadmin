import { useCallback, useEffect, useMemo, useState } from 'react'
import OptionPills from './OptionPills'
import {
  createSurvey,
  deleteSurvey,
  getSurvey,
  listCompanies,
  listSurveys,
  listUsers,
  setSurveyAdmins,
  setSurveySurveyors,
  updateSurvey,
} from './api'
import { labelPatch, slugQuestionKey } from './questionKey'

const EMPTY_Q = {
  id: '',
  label: '',
  type: 'text',
  options: [],
  required: false,
  speak: '',
}

const defaultOptionsForType = (t) => {
  if (t === 'yesno') return ['Yes', 'No']
  if (t === 'abc') return ['A', 'B', 'C', 'D']
  if (t === 'sentiment' || t === 'sentiment_text') return ['Positive', 'Neutral', 'Negative']
  if (t === 'range' || t === 'numeric_range' || t === 'age') return ['10-20', '21-30', '31-40', '41-50', '50+']
  if (t === 'choice') return ['Option 1', 'Option 2', 'Option 3']
  return []
}

/** Shared question editor with rich question types, interactive options & live app preview */
function QuestionEditor({ questions, onChange }) {
  function updateQ(i, patch) {
    onChange(questions.map((q, idx) => (idx === i ? { ...q, ...patch } : q)))
  }

  function handleTypeChange(i, newType) {
    const defaults = defaultOptionsForType(newType)
    updateQ(i, {
      type: newType,
      options: defaults,
      optionsText: defaults.join(', '),
    })
  }

  function addQ() {
    onChange([
      ...questions,
      { ...EMPTY_Q, id: '', label: '', speak: '', _uid: `n-${Date.now()}` },
    ])
  }

  function removeQ(i) {
    onChange(questions.filter((_, idx) => idx !== i))
  }

  return (
    <>
      {questions.map((q, i) => {
        const type = q.type || 'text'
        const hasOptions = ['choice', 'yesno', 'abc', 'sentiment', 'sentiment_text', 'range', 'numeric_range', 'age'].includes(type)
        const currentOpts = Array.isArray(q.options) && q.options.length > 0
          ? q.options
          : (q.optionsText || '').split(',').map((s) => s.trim()).filter(Boolean)

        return (
          <div key={q._uid || `qi-${i}`} className="card" style={{ marginBottom: 14, borderLeft: '4px solid #00e599' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <span className="pill ok" style={{ fontSize: 11, fontWeight: 'bold' }}>
                Q{i + 1} · {type.toUpperCase().replace('_', ' ')}
              </span>
              <button type="button" className="btn small danger" onClick={() => removeQ(i)}>
                Delete Q{i + 1}
              </button>
            </div>

            <label className="field">
              <span>Field ID (Unique Key)</span>
              <input
                value={q.id}
                onChange={(e) => updateQ(i, { id: e.target.value })}
                placeholder="copies the question automatically"
              />
              <span className="muted" style={{ fontSize: 11 }}>
                Fills from the question text. Edit only if you need a shorter key.
              </span>
            </label>

            <label className="field">
              <span>Question Text / Label *</span>
              <input
                value={q.label}
                onChange={(e) => updateQ(i, labelPatch(q, e.target.value))}
                placeholder="What is your age or income bracket?"
              />
            </label>

            <label className="field">
              <span>Voice Prompt (spoken by surveyor / speech fill)</span>
              <input
                value={q.speak || ''}
                onChange={(e) => updateQ(i, { speak: e.target.value })}
                placeholder="Ask respondent their age bracket"
              />
            </label>

            <label className="field">
              <span>Question Type</span>
              <select
                value={type}
                onChange={(e) => handleTypeChange(i, e.target.value)}
                style={{ fontWeight: 'bold' }}
              >
                <option value="range">🔢 Numeric Range Buttons (e.g. 10-20, 21-30, 31-40, 50+)</option>
                <option value="yesno">✓ Yes / ✕ No Buttons (Green & Red)</option>
                <option value="sentiment_text">📝 Text + Sentiment Fillers (Positive/Neutral/Negative)</option>
                <option value="choice">🔘 Choice / Custom Options (Multi-Pill)</option>
                <option value="abc">🔤 A · B · C · D Choice Buttons</option>
                <option value="sentiment">⭐ Sentiment Rating Scale (Positive/Neutral/Negative)</option>
                <option value="meter">🎚️ Sentiment Meter (tap-o-meter 1–100%)</option>
                <option value="text">✏️ Open Text Input</option>
                <option value="age">🔢 Age / Numeric Field</option>
              </select>
            </label>

            {hasOptions && (
              <div style={{ marginTop: 10, background: 'rgba(15,23,42,0.05)', border: '1px solid #e2e8f0', borderRadius: 8, padding: 12 }}>
                <label className="field" style={{ marginBottom: 8 }}>
                  <span>Answer Options / Range Pills (comma-separated list, e.g. 10-20, 21-30, 31-40, 50+)</span>
                  <input
                    value={
                      q.optionsText != null
                        ? q.optionsText
                        : (Array.isArray(q.options) && q.options.length ? q.options.join(', ') : defaultOptionsForType(type).join(', '))
                    }
                    onChange={(e) => {
                      const val = e.target.value
                      const parsed = val.split(',').map((s) => s.trim()).filter(Boolean)
                      updateQ(i, { optionsText: val, options: parsed })
                    }}
                    placeholder="10-20, 21-30, 31-40, 41-50, 50+"
                  />
                </label>

                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                  <span style={{ fontSize: 11, fontWeight: 'bold', color: '#38bdf8' }}>Active Range/Option Pills:</span>
                  <OptionPills
                    options={currentOpts.length > 0 ? currentOpts : defaultOptionsForType(type)}
                    onChange={(list) => updateQ(i, { options: list, optionsText: list.join(', ') })}
                    addLabel="+ Add Range"
                    addValue="51-60"
                  />
                </div>
              </div>
            )}

            <label
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 10,
                background: q.required ? 'rgba(5, 150, 105, 0.12)' : 'rgba(15, 23, 42, 0.05)',
                border: q.required ? '1px solid #059669' : '1px solid #e2e8f0',
                borderRadius: 8,
                padding: '10px 14px',
                cursor: 'pointer',
                margin: '10px 0 12px',
                width: 'fit-content',
              }}
            >
              <input
                type="checkbox"
                checked={!!q.required}
                onChange={(e) => updateQ(i, { required: e.target.checked })}
              />
              <span style={{ fontSize: 13, fontWeight: 'bold', color: q.required ? '#00e599' : '#e2e8f0' }}>
                {q.required ? '✓ Required Question (Surveyor must answer)' : 'Optional Question'}
              </span>
            </label>

            {/* Live App Preview */}
            <div style={{ background: 'rgba(15,23,42,0.05)', border: '1px solid #e2e8f0', borderRadius: 8, padding: 10, marginTop: 8 }}>
              <p style={{ margin: '0 0 6px', fontSize: 11, fontWeight: 'bold', color: '#38bdf8' }}>
                📱 Mobile App Preview for Surveyors:
              </p>
              {type === 'yesno' ? (
                <div style={{ display: 'flex', gap: 10 }}>
                  <button type="button" className="btn" style={{ background: '#059669', color: '#fff', fontWeight: 'bold', padding: '8px 20px', border: 0 }}>
                    ✓ YES
                  </button>
                  <button type="button" className="btn" style={{ background: '#dc2626', color: '#fff', fontWeight: 'bold', padding: '8px 20px', border: 0 }}>
                    ✕ NO
                  </button>
                </div>
              ) : type === 'sentiment_text' || type === 'sentiment' ? (
                <div>
                  {type === 'sentiment_text' && (
                    <input readOnly placeholder="Open text response…" style={{ marginBottom: 8, width: '100%' }} />
                  )}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <span style={{ background: '#059669', color: '#fff', padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 'bold' }}>
                      😀 Positive
                    </span>
                    <span style={{ background: '#d97706', color: '#fff', padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 'bold' }}>
                      😐 Neutral
                    </span>
                    <span style={{ background: '#dc2626', color: '#fff', padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 'bold' }}>
                      🙁 Negative
                    </span>
                  </div>
                </div>
              ) : type === 'abc' ? (
                <div style={{ display: 'flex', gap: 8 }}>
                  {['A', 'B', 'C', 'D'].map((letter, idx) => (
                    <span key={letter} style={{ background: ['#00e599', '#38bdf8', '#a78bfa', '#f472b6'][idx], color: '#111', padding: '6px 16px', borderRadius: 16, fontWeight: 'bold' }}>
                      {letter}
                    </span>
                  ))}
                </div>
              ) : type === 'meter' ? (
                <div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    readOnly
                    style={{ width: '100%', accentColor: '#059669' }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11 }}>
                    <span>1% · Negative</span>
                    <span>50% · Neutral</span>
                    <span>100% · Positive</span>
                  </div>
                </div>
              ) : hasOptions ? (
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {(currentOpts.length > 0 ? currentOpts : ['10-20', '21-30', '31-40', '41-50', '50+']).map((opt, idx) => (
                    <span key={idx} style={{ background: '#38bdf8', color: '#111', padding: '6px 14px', borderRadius: 16, fontSize: 13, fontWeight: 'bold' }}>
                      {opt}
                    </span>
                  ))}
                </div>
              ) : (
                <input readOnly placeholder="Surveyor types answer here…" style={{ width: '100%' }} />
              )}
            </div>
          </div>
        )
      })}
      <button
        type="button"
        className="btn primary"
        onClick={addQ}
        style={{ marginBottom: 12 }}
      >
        + Add Survey Question
      </button>
    </>
  )
}

function cleanQuestions(questions) {
  return (questions || []).map((q) => {
    const optsFromText =
      q.optionsText != null
        ? String(q.optionsText)
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
        : null
    const finalOptions =
      optsFromText && optsFromText.length > 0
        ? optsFromText
        : Array.isArray(q.options) && q.options.length > 0
          ? q.options
          : q.type === 'yesno'
            ? ['Yes', 'No']
            : q.type === 'abc'
              ? ['A', 'B', 'C', 'D']
              : q.type === 'sentiment' || q.type === 'sentiment_text'
                ? ['Positive', 'Neutral', 'Negative']
                : q.type === 'range' || q.type === 'numeric_range' || q.type === 'age'
                  ? ['10-20', '21-30', '31-40', '41-50', '50+']
                  : q.type === 'choice'
                    ? ['Option 1', 'Option 2']
                    : undefined

    return {
      id: String(q.id || '').trim() || slugQuestionKey(q.label) || `q_${Math.random().toString(36).slice(2, 8)}`,
      label: String(q.label || '').trim() || 'Question',
      type: String(q.type || 'text'),
      options: finalOptions,
      required: !!q.required,
      speak: String(q.speak || q.label || '').trim(),
    }
  })
}

export default function AdminSurveysScreen({ onToast, user }) {
  // Super Admin creates Projects; Client Admin creates Surveys (needs Create surveys power)
  const isSuper = user?.role === 'super_admin'
  const canCreate = isSuper || !!user?.can_crud_questionnaire
  const canEditQs = isSuper || !!user?.can_edit_surveys || !!user?.can_crud_questionnaire
  const canEdit = canCreate || canEditQs
  // UI noun by role
  const unit = isSuper ? 'project' : 'survey'
  const Unit = isSuper ? 'Project' : 'Survey'
  const Units = isSuper ? 'Projects' : 'Surveys'
  const [mode, setMode] = useState('list') // list | create | detail
  const [surveys, setSurveys] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  // create mode
  const [newTitle, setNewTitle] = useState('')
  const [saving, setSaving] = useState(false)
  const [exists, setExists] = useState(null) // existing survey with same name
  // Super Admin only: company + Client Admins when creating a Project
  const [newCompany, setNewCompany] = useState('')
  const [checkedAdmins, setCheckedAdmins] = useState({})
  const [companyNames, setCompanyNames] = useState([])

  // detail mode
  const [detail, setDetail] = useState(null)
  const [allSurveyors, setAllSurveyors] = useState([])
  const [checked, setChecked] = useState({})
  const [busy, setBusy] = useState(false)
  const [teamOpen, setTeamOpen] = useState(false)
  // shared access: client admins granted access to this survey (super admin only)
  const [allAdmins, setAllAdmins] = useState([])
  const [adminsOpen, setAdminsOpen] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const d = await listSurveys(search.trim())
      setSurveys(d.items || [])
    } catch (e) {
      onToast?.(e.message, 'error')
    } finally {
      setLoading(false)
    }
  }, [search, onToast])

  useEffect(() => {
    if (mode === 'list') load()
  }, [load, mode])

  // Super Admin "New project": load Client Admin accounts for the registration form
  useEffect(() => {
    if (mode === 'create' && user?.role === 'super_admin' && allAdmins.length === 0) {
      listUsers()
        .then((d) => {
          const admins = (d.users || d.surveyors || d || [])
            .filter((u) => u.role === 'admin' && u.active !== false)
          setAllAdmins(admins)
        })
        .catch(() => {})
    }
  }, [mode, user?.role, allAdmins.length])

  // Super Admin "New project": load registered companies for the company datalist
  useEffect(() => {
    if (mode === 'create' && user?.role === 'super_admin' && companyNames.length === 0) {
      listCompanies()
        .then((d) => setCompanyNames((d.items || []).map((c) => c.name)))
        .catch(() => {})
    }
  }, [mode, user?.role, companyNames.length])

  // Manual refresh only — auto-refresh disabled to prevent unwanted background database wake-ups

  // Live name filter while creating: find existing surveys matching the typed name
  const nameMatches = useMemo(() => {
    const t = newTitle.trim().toLowerCase()
    if (!t || !surveys.length) return []
    return surveys.filter((s) => String(s.title || '').toLowerCase().includes(t)).slice(0, 8)
  }, [newTitle, surveys])

  useEffect(() => {
    const t = newTitle.trim().toLowerCase()
    const hit = surveys.find((s) => String(s.title || '').toLowerCase() === t)
    setExists(hit || null)
  }, [newTitle, surveys])

  function openDetail(id) {
    setBusy(true)
    Promise.all([getSurvey(id), listUsers()])
      .then(([d, users]) => {
        setDetail(d.survey)
        const team = new Set((d.survey.surveyors || []).map((s) => Number(s.id)))
        const collect = (users.surveyors || users.users || users || [])
          .filter((u) => u.role === 'surveyor' || u.role === 'field')
        setAllSurveyors(collect)
        setChecked(Object.fromEntries(collect.map((u) => [String(u.id), team.has(Number(u.id))])))
        const admins = (users.users || users.surveyors || users || []).filter((u) => u.role === 'admin')
        setAllAdmins(admins)
        setAdminsOpen(false)
        setMode('detail')
      })
      .catch((e) => onToast?.(e.message, 'error'))
      .finally(() => setBusy(false))
  }

  async function saveNew() {
    if (!canCreate) {
      onToast?.(
        isSuper
          ? 'Cannot create project'
          : 'Super Admin has not granted Create surveys on your profile',
        'error',
      )
      return
    }
    const title = newTitle.trim()
    if (!title) {
      onToast?.(`${Unit} name required`, 'error')
      return
    }
    if (isSuper) {
      const adminIds = Object.keys(checkedAdmins).filter((k) => checkedAdmins[k]).map(Number)
      if (adminIds.length === 0) {
        onToast?.('Select at least one Client Admin who is part of this project', 'error')
        return
      }
      if (!newCompany.trim()) {
        onToast?.('Enter the company name this project is mapped under', 'error')
        return
      }
    }
    setSaving(true)
    try {
      // Super Admin: project under company + share with Client Admins
      // Client Admin: survey under their own company (no company picker)
      const d = await createSurvey({
        title,
        questions: [],
        ...(isSuper
          ? {
              company_name: newCompany.trim(),
              admin_ids: Object.keys(checkedAdmins).filter((k) => checkedAdmins[k]).map(Number),
            }
          : user?.company_name
            ? { company_name: String(user.company_name).trim() }
            : {}),
      })
      const autoN = Number(d?.auto_assigned_surveyors || 0)
      onToast?.(
        autoN > 0
          ? `${Unit} "${title}" created · assigned to ${autoN} surveyor(s) — pull-to-refresh on field app`
          : `${Unit} "${title}" created`,
        'ok',
      )
      setMode('list')
      setNewTitle('')
      setNewCompany('')
      setCheckedAdmins({})
      setExists(null)
      await load()
      if (d?.survey?.id) openDetail(d.survey.id)
    } catch (e) {
      if (e.status === 409 && e.existing_id) {
        onToast?.(`${Unit} "${title}" already exists — opening it`, 'warn')
        openDetail(e.existing_id)
      } else {
        onToast?.(e.message, 'error')
      }
    } finally {
      setSaving(false)
    }
  }

  async function saveDetailChanges() {
    if (!detail) return
    setSaving(true)
    try {
      await updateSurvey(detail.id, {
        title: detail.title,
        questions: cleanQuestions(detail.questions),
        ...(user?.role === 'super_admin' ? { company_name: detail.company_name || '' } : {}),
      })
      onToast?.(`${Unit} name + questions saved`, 'ok')
      await openDetail(detail.id)
    } catch (e) {
      onToast?.(e.message, 'error')
    } finally {
      setSaving(false)
    }
  }

  async function toggleAdmin(u) {
    if (!detail || user?.role !== 'super_admin') return
    setBusy(true)
    try {
      const ownerId = detail.owner_id != null ? Number(detail.owner_id) : null
      const on = (detail.admins || []).some((a) => Number(a.id) === Number(u.id))
      const next = on
        ? (detail.admins || []).filter((a) => Number(a.id) !== Number(u.id))
        : [...(detail.admins || []), { id: u.id, username: u.username, name: u.name || u.username }]
      // owner keeps access regardless — only shared (granted) admins go in the PUT
      const putIds = next.filter((a) => Number(a.id) !== ownerId).map((a) => Number(a.id))
      await setSurveyAdmins(detail.id, putIds)
      setDetail({ ...detail, admins: next, admin_count: next.length })
      onToast?.(`${u.username} ${on ? 'removed from' : 'granted'} access to this project`, 'ok')
      setAdminsOpen(false)
    } catch (e) {
      onToast?.(e.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  async function toggleTeamMember(u) {
    if (!detail) return
    setBusy(true)
    try {
      const nextIds = Object.keys(checked).filter((k) => checked[k]).map(Number)
      const idx = nextIds.indexOf(Number(u.id))
      if (idx >= 0) nextIds.splice(idx, 1)
      else nextIds.push(Number(u.id))
      await setSurveySurveyors(detail.id, nextIds)
      onToast?.(idx >= 0 ? `Removed ${u.username} from team` : `Added ${u.username} to team`, 'ok')
      setTeamOpen(false)
      await openDetail(detail.id)
    } catch (e) {
      onToast?.(e.message, 'error')
      setBusy(false)
    }
  }

  async function removeSurvey() {
    if (!canEdit) {
      onToast?.('Super Admin has not granted your account survey-editing rights', 'error')
      return
    }
    if (!detail || !window.confirm(`Delete project "${detail.title}"? Team assignments are removed too.`)) return
    setBusy(true)
    try {
      await deleteSurvey(detail.id)
      onToast?.(`${Unit} deleted`, 'ok')
      setDetail(null)
      setMode('list')
      await load()
    } catch (e) {
      onToast?.(e.message, 'error')
    } finally {
      setBusy(false)
    }
  }

  if (mode === 'create') {
    return (
      <div className="screen">
        <header className="screen-head">
          <h2>{isSuper ? 'New project' : 'New survey'}</h2>
          <button type="button" className="btn small" onClick={() => setMode('list')}>
            ← Back
          </button>
        </header>

        {!canCreate && (
          <div
            className="card"
            style={{
              marginBottom: 12,
              border: '1px solid rgba(217,119,6,0.5)',
              background: 'rgba(217,119,6,0.08)',
              padding: '12px 14px',
              fontSize: 13,
            }}
          >
            🔒 <strong>{Units} are read-only for you.</strong>{' '}
            {isSuper
              ? 'You cannot create projects right now.'
              : (
                <>
                  Super Admin must grant <strong>Create surveys</strong> on your Client Admin
                  profile (Super Admin → Client Admins → Profile). Super Admin creates{' '}
                  <strong>Projects</strong>; you create <strong>Surveys</strong>.
                </>
              )}
          </div>
        )}
        <div className="card" style={{ marginBottom: 12 }}>
          <label className="field">
            <span>{Unit} name</span>
            <input
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder={
                isSuper ? 'e.g. Warangal Pre-poll 2026' : 'e.g. Assembly field survey — Ward 12'
              }
              autoFocus
              disabled={!canCreate}
            />
          </label>
          {!isSuper && user?.company_name ? (
            <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>
              🏢 Your company: <strong>{user.company_name}</strong> (set by Super Admin — surveys
              are filed under this company).
            </p>
          ) : null}
          <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>
            Filter existing {unit}s by name to avoid duplicates.
          </p>
          {exists && (
            <p className="toast warn" style={{ marginTop: 8 }}>
              "{exists.title}" already exists — saving opens it instead.
            </p>
          )}
          {!exists && nameMatches.length > 0 && (
            <div style={{ marginTop: 8 }}>
              <span className="muted" style={{ fontSize: 12 }}>
                Existing {unit}s matching "{newTitle}":
              </span>
              {nameMatches.map((s) => (
                <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                  <button
                    type="button"
                    className="btn small"
                    onClick={() => openDetail(s.id)}
                  >
                    Open
                  </button>
                  <span style={{ fontSize: 13 }}>
                    {s.title}{' '}
                    <span className="muted">
                      · {s.question_count} Q · {s.surveyors} surveyor(s)
                    </span>
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {user?.role === 'super_admin' && (
          <div className="card" style={{ marginBottom: 12 }}>
            <h3 style={{ marginTop: 0, fontSize: 15 }}>🏢 Register company & Client Admins</h3>
            <label className="field">
              <span>Company name (project is mapped under this company)</span>
              <input
                value={newCompany}
                onChange={(e) => setNewCompany(e.target.value)}
                placeholder="e.g. Acme Research"
                list="registered-companies"
              />
            </label>
            <datalist id="registered-companies">
              {companyNames.map((n) => (
                <option key={n} value={n} />
              ))}
            </datalist>
            <p className="muted" style={{ fontSize: 12, margin: '12px 0 6px' }}>
              Client Admins who are <strong>part of this project</strong> (at least one)
              {Object.keys(checkedAdmins).filter((k) => checkedAdmins[k]).length > 0
                ? ` · ${Object.keys(checkedAdmins).filter((k) => checkedAdmins[k]).length} selected`
                : ''}:
            </p>
            {allAdmins.length === 0 ? (
              <p className="muted" style={{ fontSize: 12, margin: 0 }}>
                No Client Admin accounts yet — create them in the Client Admins tab first.
              </p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {allAdmins.map((u) => (
                  <label
                    key={u.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      background: checkedAdmins[String(u.id)] ? '#c8f5df' : 'rgba(15,23,42,0.05)',
                      border: checkedAdmins[String(u.id)] ? '1px solid #059669' : '1px solid #e2e8f0',
                      borderRadius: 8,
                      padding: '9px 12px',
                      cursor: 'pointer',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={!!checkedAdmins[String(u.id)]}
                      onChange={(e) =>
                        setCheckedAdmins((c) => ({ ...c, [String(u.id)]: e.target.checked }))
                      }
                    />
                    <span style={{ fontSize: 13, fontWeight: 600 }}>
                      {u.name || u.username}
                      <span className="muted" style={{ fontWeight: 400 }}>
                        {' '}@{u.username}
                        {u.company_name ? ` · ${u.company_name}` : ''}
                      </span>
                    </span>
                  </label>
                ))}
              </div>
            )}
            <p className="muted" style={{ fontSize: 11, margin: '8px 0 0' }}>
              Selected Client Admins get shared access and see this project under Surveys —
              the Super Admin remains the owner.
            </p>
          </div>
        )}

        <p className="muted" style={{ fontSize: 12, margin: '8px 0 0' }}>
          Questions are added after creating — open the project to edit them (name, questions, team).
        </p>

        <button
          type="button"
          className="btn primary"
          onClick={saveNew}
          disabled={
            saving ||
            !newTitle.trim() ||
            !canEdit ||
            (user?.role === 'super_admin' &&
              (!newCompany.trim() ||
                Object.keys(checkedAdmins).filter((k) => checkedAdmins[k]).length === 0))
          }
        >
          {saving ? 'Creating…' : 'Create project'}
        </button>
      </div>
    )
  }

  if (mode === 'detail' && detail) {
    // Projects are mapped under a company: the owning Client Admin's company.
    const ownerCompany =
      (detail.admins || []).find((a) => Number(a.id) === Number(detail.owner_id))?.company_name ||
      null
    return (
      <div className="screen">
        <header className="screen-head">
          <h2>{Unit} · {detail.title}</h2>
          <button type="button" className="btn small" onClick={() => setMode('list')}>
            ← Back
          </button>
        </header>

        <div className="card" style={{ marginBottom: 12, borderLeft: '4px solid #00e599' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
            <span style={{ fontSize: 12, color: '#059669', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              🔒 Project Name (Locked / Non-Editable)
            </span>
            <span style={{ fontSize: 11, color: '#64748b' }}>form_key: {detail.form_key}</span>
          </div>
          <h3 style={{ margin: '4px 0 8px', fontSize: 20, color: '#0f172a', fontWeight: 'bold' }}>
            {detail.title}
          </h3>
          {user?.role === 'super_admin' && (
            <label className="field" style={{ marginTop: 8, maxWidth: 420 }}>
              <span>Company (project mapped under)</span>
              <input
                value={detail.company_name || ownerCompany || ''}
                onChange={(e) => setDetail({ ...detail, company_name: e.target.value })}
                placeholder="e.g. Acme Research"
                list="registered-companies"
              />
            </label>
          )}
          <p className="muted" style={{ fontSize: 12, margin: '4px 0 0' }}>
            {user?.role === 'super_admin'
              ? `🏢 Home company: ${detail.company_name || ownerCompany || 'No company'} · ${(detail.admins || []).length} client admin(s) — ${(detail.admins || []).map((a) => `${a.company_name || 'No company'} · ${a.name || a.username}`).join(', ') || 'none connected yet'}`
              : <>👥 <strong>Field Team (People who take survey):</strong>{' '}{(detail.surveyors || []).length > 0
                ? (detail.surveyors || []).map((s) => s.username || s.name).join(', ')
                : 'No surveyors assigned yet'}</>}
          </p>
        </div>

        {user?.role !== 'super_admin' && <>
        <h3 style={{ fontSize: 14, margin: '10px 0 6px' }}>Survey people — field team</h3>
        <div className="card" style={{ marginBottom: 12, padding: 12 }}>
          {allSurveyors.length === 0 ? (
            <p className="muted" style={{ fontSize: 12, margin: 0 }}>
              No surveyor accounts yet — create them in the Users tab first.
            </p>
          ) : (
            <>
              <button
                type="button"
                className="btn small primary"
                style={{ width: '100%', textAlign: 'left' }}
                onClick={() => setTeamOpen((o) => !o)}
              >
                {Object.keys(checked).filter((k) => checked[k]).length > 0
                  ? `${Object.keys(checked).filter((k) => checked[k]).length} surveyor(s) in team — tap to edit`
                  : 'Add surveyors…'}
              </button>
              {teamOpen && (
                <div
                  style={{
                    background: '#fff',
                    color: '#111',
                    border: '1px solid rgba(0,0,0,0.2)',
                    borderRadius: 12,
                    padding: 6,
                    maxHeight: 220,
                    overflowY: 'auto',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
                  }}
                >
                  {allSurveyors.map((u) => {
                    const on = checked[String(u.id)]
                    return (
                      <button
                        key={u.id}
                        type="button"
                        disabled={busy}
                        onClick={() => toggleTeamMember(u)}
                        style={{
                          display: 'flex',
                          width: '100%',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: 8,
                          padding: '10px 12px',
                          border: 'none',
                          borderRadius: 8,
                          background: on ? '#c8f5df' : 'transparent',
                          color: '#111',
                          fontSize: 14,
                          fontWeight: 600,
                          cursor: 'pointer',
                          textAlign: 'left',
                        }}
                      >
                        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {u.username}
                        </span>
                        {on ? (
                          <span style={{ color: '#00a86b', fontSize: 16, fontWeight: 700, flexShrink: 0 }}>
                            ✓
                          </span>
                        ) : null}
                      </button>
                    )
                  })}
                  <button
                    type="button"
                    onClick={() => setTeamOpen(false)}
                    style={{
                      width: '100%',
                      marginTop: 4,
                      padding: '8px',
                      border: 'none',
                      borderRadius: 8,
                      background: 'rgba(0,0,0,0.06)',
                      color: '#111',
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                  >
                    Done
                  </button>
                </div>
              )}
              {Object.keys(checked).filter((k) => checked[k]).length === 0 && (
                <p className="muted" style={{ fontSize: 12, margin: 0 }}>
                  No surveyors assigned yet — open the dropdown above.
                </p>
              )}
              {Object.keys(checked)
                .filter((k) => checked[k])
                .map((k) => {
                  const u = allSurveyors.find((x) => String(x.id) === k)
                  if (!u) return null
                  return (
                    <div
                      key={k}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8,
                        padding: '5px 0',
                        borderTop: '1px solid rgba(128,128,128,0.15)',
                        fontSize: 13,
                      }}
                    >
                      <span style={{ flex: 1, minWidth: 0 }}>
                        {u.username}
                        {u.display_name ? ` (${u.display_name})` : ''}
                      </span>
                      <button
                        type="button"
                        className="btn small danger"
                        onClick={() => toggleTeamMember(u)}
                        disabled={busy}
                        style={{
                          color: '#ff6b6b',
                          borderColor: 'rgba(255,107,107,0.4)',
                          background: 'transparent',
                          minHeight: 0,
                          padding: '6px 10px',
                          fontSize: 13,
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  )
                })}
            </>
          )}
        </div>
        </>}

        <h3 style={{ fontSize: 14, margin: '14px 0 6px' }}>🏢 Client Admins connected to this project</h3>
        <div className="card" style={{ marginBottom: 12, padding: 12 }}>
          {user?.role === 'super_admin' ? (
            <>
              <button
                type="button"
                className="btn small primary"
                style={{ width: '100%', textAlign: 'left' }}
                onClick={() => setAdminsOpen((o) => !o)}
              >
                {(detail.admins || []).length > 0
                  ? `${detail.admins.length} client admin(s) have access — tap to edit`
                  : 'Share with client admins…'}
              </button>
              {adminsOpen && (
                <div
                  style={{
                    background: '#fff',
                    color: '#111',
                    border: '1px solid rgba(0,0,0,0.2)',
                    borderRadius: 12,
                    padding: 6,
                    maxHeight: 240,
                    overflowY: 'auto',
                    boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
                  }}
                >
                  {allAdmins.length === 0 ? (
                    <p className="muted" style={{ fontSize: 12, margin: 6 }}>
                      No client admin accounts yet — create them in the Client Admins tab.
                    </p>
                  ) : (
                    allAdmins.map((u) => {
                      const isOwner = detail.owner_id != null && Number(u.id) === Number(detail.owner_id)
                      const on = (detail.admins || []).some((a) => Number(a.id) === Number(u.id))
                      return (
                        <button
                          key={u.id}
                          type="button"
                          disabled={busy || isOwner}
                          onClick={() => toggleAdmin(u)}
                          style={{
                            display: 'flex',
                            width: '100%',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: 8,
                            padding: '10px 12px',
                            border: 'none',
                            borderRadius: 8,
                            background: on ? '#ede9fe' : 'transparent',
                            color: '#111',
                            fontSize: 14,
                            fontWeight: 600,
                            cursor: isOwner ? 'default' : 'pointer',
                            opacity: isOwner ? 0.65 : 1,
                            textAlign: 'left',
                          }}
                        >
                          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {u.username}
                            {u.name && u.name !== u.username ? ` (${u.name})` : ''}
                            {u.company_name ? ` · ${u.company_name}` : ''}
                            {isOwner ? ' · owner' : ''}
                          </span>
                          {on ? (
                            <span style={{ color: '#7c3aed', fontSize: 16, fontWeight: 700, flexShrink: 0 }}>
                              ✓
                            </span>
                          ) : null}
                        </button>
                      )
                    })
                  )}
                  <button
                    type="button"
                    onClick={() => setAdminsOpen(false)}
                    style={{
                      width: '100%',
                      marginTop: 4,
                      padding: '8px',
                      border: 'none',
                      borderRadius: 8,
                      background: 'rgba(0,0,0,0.06)',
                      color: '#111',
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                  >
                    Done
                  </button>
                </div>
              )}
              <p className="muted" style={{ fontSize: 11, margin: '6px 0 0' }}>
                Projects are mapped under a company — this project's home company is{' '}
                <strong>{detail.company_name || ownerCompany || 'No company'}</strong>. Connect
                Client Admins by company to share it; surveyors are never connected or managed by
                Super Admin. Connected Client Admins see the project in their Projects tab.
              </p>
            </>
          ) : (
            <p style={{ fontSize: 13, margin: 0 }}>
              {(detail.admins || []).length > 0
                ? `👥 ${detail.admins.length} client admin(s) can access this project — ${detail.admins.map((a) => a.name || a.username).join(', ')}`
                : '👥 No other client admins have access to this project.'}
              {detail.owner && (
                <span className="muted"> · owner: {detail.owner}</span>
              )}
            </p>
          )}
        </div>

        <p className="muted" style={{ fontSize: 12, margin: '8px 0 0' }}>
          Survey questions — add/edit here. Options support text, choice, Yes/No, A·B·C·D,
          sentiment (Positive/Neutral/Negative) and age (auto ranges in report).
        </p>

        <h3 style={{ fontSize: 14, margin: '14px 0 6px' }}>Survey questions</h3>
        <QuestionEditor
          questions={detail.questions || []}
          onChange={(qs) => setDetail({ ...detail, questions: qs })}
          onToast={onToast}
        />

        <button
          type="button"
          className="btn primary"
          onClick={saveDetailChanges}
          disabled={saving || busy}
        >
          {saving ? 'Saving…' : 'Save project (name + questions)'}
        </button>
        <button
          type="button"
          className="btn danger"
          onClick={removeSurvey}
          disabled={busy}
          style={{ marginLeft: 8 }}
        >
          Delete project
        </button>
      </div>
    )
  }

  const renderCard = (s) => {
    const mine = Number(s.created_by) === Number(user?.id)
    const sharedProject =
      !isSuper && !mine && (s.company_name || s.owner_company || s.admin_count > 0)
    return (
    <div
      key={s.id}
      className="card"
      style={{
        marginBottom: 10,
        padding: 14,
        borderLeft: `4px solid ${sharedProject ? '#7c3aed' : '#00e599'}`,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button
          type="button"
          className="btn small primary"
          onClick={() => openDetail(s.id)}
          disabled={busy}
          style={{ fontWeight: 'bold', padding: '8px 16px' }}
        >
          Open
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <strong style={{ fontSize: 16, color: '#0f172a' }}>{s.title}</strong>
            {sharedProject ? (
              <span
                className="pill"
                style={{
                  background: 'rgba(124, 58, 237, 0.12)',
                  color: '#5b21b6',
                  fontWeight: 700,
                  fontSize: 11,
                }}
              >
                Super Admin project · {s.company_name || user?.company_name || 'company'}
              </span>
            ) : !isSuper ? (
              <span
                className="pill"
                style={{
                  background: 'rgba(0, 229, 153, 0.12)',
                  color: '#047857',
                  fontWeight: 700,
                  fontSize: 11,
                }}
              >
                Your survey
              </span>
            ) : null}
          </div>
          {user?.role === 'super_admin' && (
            <div style={{ fontSize: 13, color: '#334155', fontWeight: 600, marginTop: 3 }}>
              🏢 {s.company_name || s.owner_company || 'No company'}
              {s.owner_name ? ` · owned by ${s.owner_name}` : ''}
            </div>
          )}
          {user?.role !== 'super_admin' && (
            <div style={{ fontSize: 13, color: '#38bdf8', fontWeight: 'bold', marginTop: 3 }}>
              👥 Field Team: {s.surveyor_names || `${s.surveyors || 0} assigned surveyor(s)`}
            </div>
          )}
          <div className="muted" style={{ fontSize: 12, marginTop: 3 }}>
            📊 {s.submissions || 0} Submissions · 📋 {s.question_count || 0} Questions · Updated{' '}
            {String(s.updated_at || '').slice(0, 16).replace('T', ' ')}
          </div>
          {isSuper && s.admin_count > 0 && (
            <div className="muted" style={{ fontSize: 12, marginTop: 3, color: '#7c3aed' }}>
              🏢 {s.admin_count} client admin(s) connected
              {s.admin_names ? ` — ${s.admin_names}` : ''}
            </div>
          )}
          {sharedProject && (
            <div className="muted" style={{ fontSize: 12, marginTop: 3, color: '#5b21b6' }}>
              Created by Super Admin for company {s.company_name || user?.company_name || '—'}. You can
              open and run field work; you did not create this as your own survey.
            </div>
          )}
        </div>
      </div>
    </div>
    )
  }

  return (
    <div className="screen">
      <header className="screen-head">
        <h2>{Units}</h2>
        <p className="muted" style={{ fontSize: 12, margin: '4px 0 0' }}>
          {isSuper
            ? 'Super Admin creates Projects and maps them to companies & Client Admins.'
            : 'Client Admin creates Surveys under your company. Super Admin creates shared Projects separately.'}
        </p>
        <button
          type="button"
          className="btn"
          onClick={() => load()}
          disabled={loading}
          style={{ marginRight: 8 }}
        >
          ⟳ Refresh
        </button>
        <button
          type="button"
          className="btn primary"
          disabled={!canCreate}
          title={
            canCreate
              ? undefined
              : 'Ask Super Admin to grant Create surveys on your profile'
          }
          onClick={() => {
            setNewTitle('')
            setNewCompany('')
            setCheckedAdmins({})
            setExists(null)
            setMode('create')
          }}
        >
          + New {unit}
        </button>
      </header>

      <div className="card" style={{ marginBottom: 12 }}>
        <label className="field">
          <span>Filter by {unit} name</span>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={`Type a ${unit} name…`}
          />
        </label>
      </div>

      {loading && <p className="muted">Loading projects…</p>}

      {!loading && surveys.length === 0 && (
        <p className="muted">
          {search
            ? `No ${unit}s match that name.`
            : `No ${unit}s yet — click "+ New ${unit}".`}
        </p>
      )}

      {user?.role === 'super_admin' && surveys.length > 0 ? (
        <>
          {Object.entries(
            surveys.reduce((acc, s) => {
              const c = s.company_name || s.owner_company || 'No company'
              ;(acc[c] = acc[c] || []).push(s)
              return acc
            }, {})
          ).map(([company, items]) => (
            <div key={company}>
              <h3 style={{ fontSize: 14, margin: '16px 0 8px', color: '#334155' }}>
                🏢 {company}
                <span className="muted" style={{ fontSize: 12, fontWeight: 400 }}>
                  {' '}· {items.length} project{items.length === 1 ? '' : 's'}
                </span>
              </h3>
              {items.map(renderCard)}
            </div>
          ))}
        </>
      ) : (
        surveys.map(renderCard)
      )}
    </div>
  )
}
